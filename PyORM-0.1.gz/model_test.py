from os import *
from Model import *

if __name__ == "__main__":
	test = Model()
	Model.test = '1'

	print Model.test


